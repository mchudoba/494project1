﻿using UnityEngine;
using System.Collections;

public class Fist_Obj : MonoBehaviour
{
	
	void Start ()
	{
		this.renderer.enabled = false;
		this.collider.enabled = false;
	}

}
